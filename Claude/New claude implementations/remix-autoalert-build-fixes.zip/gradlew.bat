@rem Minimal Gradle wrapper launcher (Windows). Requires gradle\wrapper\gradle-wrapper.jar.
@rem Regenerate the official files with: gradle wrapper --gradle-version 9.3.1
@echo off
setlocal
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%CLASSPATH%" (
  echo ERROR: %CLASSPATH% is missing. 1>&2
  echo Generate it once with: gradle wrapper --gradle-version 9.3.1 1>&2
  exit /b 1
)
if defined JAVA_HOME (set JAVA_EXE=%JAVA_HOME%\bin\java.exe) else (set JAVA_EXE=java.exe)
"%JAVA_EXE%" -Xmx64m -Xms64m -Dfile.encoding=UTF-8 "-Dorg.gradle.appname=gradlew" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
